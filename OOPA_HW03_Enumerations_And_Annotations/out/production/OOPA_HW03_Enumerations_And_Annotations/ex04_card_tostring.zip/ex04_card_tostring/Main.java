package ex04_card_tostring;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        //CardRank[] ranks = CardRank.values();
        //CardSuit[] suits = CardSuit.values();

        String cardRank = reader.readLine();
        String cardSuit = reader.readLine();
        //int powerSum = CardSuit.valueOf(cardSuit).getSuitPower() + CardRank.valueOf(cardRank).getCardPower();

        Card card = new Card(cardRank, cardSuit);
        System.out.println(card.toString());

        //System.out.println(String.format("Card name: %s of %s; Card power: %d", cardRank, cardSuit, powerSum));

    }
}