package ex01_card_suit;

public enum CardSuit {
    CLUBS, DIAMONDS, HEARTS, SPADES;
}
