package ex01_logger.io.io_interfaces;

public interface Reader {
    String readLine();
}
