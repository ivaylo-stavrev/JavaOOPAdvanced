package ex01_logger.io.io_interfaces;

public interface Writer {
    void writeLine(String line);
}
