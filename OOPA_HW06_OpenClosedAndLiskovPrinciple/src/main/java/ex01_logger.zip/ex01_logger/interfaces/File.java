package ex01_logger.interfaces;

public interface File {
    void write(String log);

    long getSize();
}
