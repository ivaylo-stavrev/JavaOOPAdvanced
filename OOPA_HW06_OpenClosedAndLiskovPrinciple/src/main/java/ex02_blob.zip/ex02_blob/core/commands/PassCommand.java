package ex02_blob.core.commands;

import ex02_blob.interfaces.Executable;

public class PassCommand implements Executable {
    @Override
    public void execute() {
        return;
    }
}
