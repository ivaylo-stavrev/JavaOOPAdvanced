package ex02_blob.io.io_interfaces;

public interface Reader {
    String readLine();
}
