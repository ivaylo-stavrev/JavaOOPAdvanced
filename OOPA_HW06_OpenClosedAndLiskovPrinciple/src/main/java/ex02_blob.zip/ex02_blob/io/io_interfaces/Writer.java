package ex02_blob.io.io_interfaces;

public interface Writer {
    void writeLine(String line);
}
