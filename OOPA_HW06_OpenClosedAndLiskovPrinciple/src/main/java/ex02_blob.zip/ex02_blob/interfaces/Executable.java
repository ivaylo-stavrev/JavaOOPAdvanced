package ex02_blob.interfaces;

public interface Executable {
    //void execute(String commandType);
    void execute();
}
