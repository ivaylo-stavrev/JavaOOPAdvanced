package io.io_interfaces;

public interface Reader {
    String readLine();
}
