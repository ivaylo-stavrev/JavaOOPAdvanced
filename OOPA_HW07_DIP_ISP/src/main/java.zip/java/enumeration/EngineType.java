package enumeration;

public enum EngineType
{
    JET,
    STERNDRIVE
}
