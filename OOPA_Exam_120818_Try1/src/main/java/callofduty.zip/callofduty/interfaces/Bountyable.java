package callofduty.interfaces;

public interface Bountyable {
    Double getBounty();
}
