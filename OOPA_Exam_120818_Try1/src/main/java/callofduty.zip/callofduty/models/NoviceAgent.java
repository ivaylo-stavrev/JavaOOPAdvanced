package callofduty.models;

public class NoviceAgent extends BaseAgent {

    public NoviceAgent(String id, String name) {
        super(id, name);
    }

}
